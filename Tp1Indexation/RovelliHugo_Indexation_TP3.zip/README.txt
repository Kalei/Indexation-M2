-----------Tp3 Indexation--------------
---------------------------------------
Par: Hugo Rovelli

TFIDF:
	-> TF:
		-> Test avec fr�quence calcul� par occurence du mot dans le document/nombre de mots dans le document
			-> J'ai finalement retenu seulement l'occurence.

	-> IDF:
		-> log (nombre de documents total / nb documents contenant le mot)

---------------------------------------------------------------------------------------------

Jaccard:
	
	-> Appliquer la pond�ration tfidf pour l'ensemble des textes du corpus
		-> Plus le documents contient de mots appartenant � la requete plus son score augmente
		-> Si un texte ne contient aucun �l�ment de la requ�te sa valeur sera 0.0

	-> On divise par l'ensemeble des tfidf correspondant au documents contenant au moins un des mots de la requ�te

-----------------------------------------------------------------------------------------------

Requete exacte postionnelle:

	-> Requ�te exacte:
		-> On r�ccup�re l'enssemble des document contenant la requ�te exacte
		-> On pond�re la requ�te avec Jaccard pui on compare avec les documents trouv�s par la requ�te exacte
			-> Si les documents correspondent on y ajoute 0.5

	-> Requ�te positionnelle:
		-> On fais la m�me chose que dans la requ�te exacte sauf que l'on test pour le premier et le dernier mot
		   si il existe un mot d�fini � la position +n ou -n

		-> ajout de 0.5 �galement.

Pour un corpus simple compos� de documents contenant de simple lettres espac�, tapper 'default' au d�marrage du programme.

Ps: Je me suis rendu compte qu'une modification de derni�re minute lors du rendu pr�c�dent faisait bugu� les AND, 
une simple suppression de condition a suffit � y rem�dier. 
	
		